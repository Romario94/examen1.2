<?php

return [
    [
        'uid' => 5,
        'idP' => 1,
        'cantidad' => 2,
    ],
    [
        'uid' => 6,
        'idP' => 2,
        'cantidad' => 7,
    ],
    [
        'uid' => 5,
        'idP' => 3,
        'cantidad' => 4,
    ],
    [
        'uid' => 7,
        'idP' => 3,
        'cantidad' => 8,
    ],
];
